/**
 * Rate Limiter for API requests and token usage
 * Prevents exceeding Anthropic API rate limits
 *
 * This uses a sliding window so requests immediately before and after a
 * minute boundary still count toward the same 60-second budget. Fixed
 * buckets can admit two full bursts around that boundary.
 *
 * Concepts:
 * - Tracks requests and tokens used in the last 60 seconds (sliding window)
 * - Limits concurrent requests to prevent overwhelming the API
 * - Tracks requests and estimated tokens separately because a few large
 *   requests can exhaust the token budget while many small requests can
 *   hit the request limit first.
 */

export interface RateLimiterConfig {
  /** Maximum requests per minute */
  maxRequestsPerMinute: number;
  /** Maximum tokens per minute */
  maxTokensPerMinute: number;
  /** Maximum concurrent requests */
  maxConcurrent: number;
}

export const DEFAULT_RATE_LIMITS: RateLimiterConfig = {
  maxRequestsPerMinute: 50,      // Conservative default
  maxTokensPerMinute: 100000,    // ~100k tokens/min
  maxConcurrent: 5               // Max parallel requests
};

interface RequestRecord {
  timestamp: number;
  tokens: number;
}

/**
 * Token bucket rate limiter with sliding window
 */
export class RateLimiter {
  private config: RateLimiterConfig;
  private requestHistory: RequestRecord[] = [];
  private activeRequests: number = 0;
  private waitQueue: Array<() => void> = [];

  constructor(config: Partial<RateLimiterConfig> = {}) {
    this.config = { ...DEFAULT_RATE_LIMITS, ...config };
    if (Object.values(this.config).some(limit => !Number.isSafeInteger(limit) || limit < 1)) {
      throw new RangeError('Rate limits must be positive integers.');
    }
  }

  /**
   * Wait until a request can be made within rate limits
   *
   * This is the main entry point for rate limiting.
   * It ensures:
   * 1. Concurrent request limit is not exceeded
   * 2. Request and token rate limits are respected
   * 3. The request is recorded for future rate limit calculations
   *
   * @param estimatedTokens - Estimated tokens for this request
   */
  async acquire(estimatedTokens: number = 1000): Promise<void> {
    if (!Number.isSafeInteger(estimatedTokens) || estimatedTokens < 0 ||
        estimatedTokens > this.config.maxTokensPerMinute) {
      throw new RangeError('Estimated tokens must fit the per-minute limit.');
    }
    do {
      await this.waitForRateLimit(estimatedTokens);
    } while (!this.canProceed(estimatedTokens));
    this.activeRequests++;
    this.requestHistory.push({ timestamp: Date.now(), tokens: estimatedTokens });
  }

  /**
   * Release a request slot after completion
   *
   * The optional token adjustment targets the latest history record.
   * With concurrent requests, that record may belong to another request.
   * Accurate adjustments require a per-request handle shared by acquire()
   * and release(). The review wrapper omits actualTokens.
   *
   * @param actualTokens - Actual tokens used, for serial callers only
   */
  release(actualTokens?: number): void {
    this.activeRequests = Math.max(0, this.activeRequests - 1);

    const lastRequest = this.requestHistory[this.requestHistory.length - 1];
    if (actualTokens !== undefined && lastRequest) {
      lastRequest.tokens = actualTokens;
    }

    // Wake up next waiting request
    const next = this.waitQueue.shift();
    if (next) next();
  }

  /**
   * Get current rate limit status
   */
  getStatus(): {
    activeRequests: number;
    requestsInWindow: number;
    tokensInWindow: number;
    availableRequests: number;
    availableTokens: number;
  } {
    this.pruneOldRecords();

    const requestsInWindow = this.requestHistory.length;
    const tokensInWindow = this.requestHistory.reduce((sum, r) => sum + r.tokens, 0);

    return {
      activeRequests: this.activeRequests,
      requestsInWindow,
      tokensInWindow,
      availableRequests: Math.max(0, this.config.maxRequestsPerMinute - requestsInWindow),
      availableTokens: Math.max(0, this.config.maxTokensPerMinute - tokensInWindow)
    };
  }

  /**
   * Check if request can proceed immediately
   *
   * @param estimatedTokens - Estimated tokens for the request
   * @returns true if the request can proceed without waiting
   */
  canProceed(estimatedTokens: number = 1000): boolean {
    const { activeRequests, requestsInWindow, tokensInWindow } = this.getStatus();

    return activeRequests < this.config.maxConcurrent &&
      requestsInWindow < this.config.maxRequestsPerMinute &&
      tokensInWindow + estimatedTokens <= this.config.maxTokensPerMinute;
  }

  /**
   * Wait for a concurrent request slot to become available
   *
   * Each waiter appends its Promise resolver to waitQueue. On release(),
   * the oldest resolver is removed and called. The awakened request checks
   * the limits again before taking a slot.
   */
  private async waitForSlot(): Promise<void> {
    await new Promise<void>(resolve => this.waitQueue.push(resolve));
  }

  /**
   * Wait until rate limits allow the request to proceed
   *
   * This implements the sliding window algorithm.
   * If we can't proceed immediately, we calculate how long to wait
   * until the oldest request expires (falls out of the 60-second window).
   *
   * @param estimatedTokens - Estimated tokens for the request
   */
  private async waitForRateLimit(estimatedTokens: number): Promise<void> {
    while (!this.canProceed(estimatedTokens)) {
      if (this.activeRequests >= this.config.maxConcurrent) {
        await this.waitForSlot();
        continue;
      }
      const oldest = this.requestHistory[0];
      if (!oldest) return;
      const wait = oldest.timestamp + 60000 - Date.now() + 100;
      await new Promise(resolve => setTimeout(resolve, Math.min(5000, Math.max(100, wait))));
    }
  }

  /**
   * Remove request records older than 60 seconds (sliding window)
   *
   * This is called before checking rate limits to ensure we only
   * count requests in the current 60-second window.
   */
  private pruneOldRecords(): void {
    const cutoff = Date.now() - 60000;
    this.requestHistory = this.requestHistory.filter(record => record.timestamp > cutoff);
  }
}

/**
 * Wrap an async function with rate limiting
 *
 * This is a convenience function for applying rate limiting to any async operation.
 */
export async function withRateLimit<T>(
  rateLimiter: RateLimiter,
  fn: () => Promise<T>,
  estimatedTokens: number = 1000
): Promise<T> {
  await rateLimiter.acquire(estimatedTokens);
  try {
    return await fn();
  } finally {
    rateLimiter.release();
  }
}

// Global rate limiter instance
export const globalRateLimiter = new RateLimiter();
